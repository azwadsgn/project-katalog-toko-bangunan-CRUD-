<?php
session_start();
require_once '../config/database.php';


if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}


$stmt = $pdo->prepare("SELECT * FROM products ORDER BY id DESC");
$stmt->execute();
$products = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Manager - Toko Bangunan</title>
    <style>
        * { box-sizing: border-box; font-family: Arial, sans-serif; }
        body { margin: 20px; background-color: #f4f6f9; }
        .container { max-width: 1100px; margin: auto; }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .btn { padding: 10px 15px; text-decoration: none; border-radius: 5px; color: white; border: none; cursor: pointer; }
        .btn-add { background-color: #28a745; }
        .btn-edit { background-color: #ffc107; color: #333; }
        .btn-delete { background-color: #dc3545; }
        .alert { padding: 10px; margin-bottom: 15px; border-radius: 5px; background-color: #d4edda; color: #155724; }
        
        .card-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px; }
        .card { background: white; border-radius: 8px; padding: 15px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .card h3 { margin-top: 0; color: #333; }
        .badge { background: #17a2b8; color: white; padding: 3px 8px; border-radius: 3px; font-size: 0.8em; }
        .price { font-size: 1.2em; font-weight: bold; color: #d9534f; margin: 10px 0; }
        .card-actions { display: flex; gap: 10px; margin-top: 15px; }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <h2>Katalog Material Bangunan - Toko Bangunan Azwa</h2>
        <a href="create.php" class="btn btn-add">+ Tambah Material Baru</a>
    </div>

    <?php if (isset($_SESSION['flash_message'])): ?>
        <div class="alert"><?= htmlspecialchars($_SESSION['flash_message']); ?></div>
        <?php unset($_SESSION['flash_message']); ?>
    <?php endif; ?>

    <div class="card-grid">
        <?php foreach ($products as $product): ?>
            <div class="card">
                
                <h3><?= htmlspecialchars($product['name'], ENT_QUOTES, 'UTF-8'); ?></h3>
                <span class="badge"><?= htmlspecialchars($product['category'], ENT_QUOTES, 'UTF-8'); ?></span>
                
                <div class="price">Rp <?= number_format($product['price'], 0, ',', '.'); ?></div>
                <p>Stok: <strong><?= (int)$product['stock']; ?></strong> unit</p>
                
                <div class="card-actions">
                    <a href="edit.php?id=<?= $product['id']; ?>" class="btn btn-edit">Edit</a>
                    
                    
                    <form action="delete.php" method="POST" onsubmit="return confirm('Yakin ingin menghapus material ini?');">
                        <input type="hidden" name="id" value="<?= $product['id']; ?>">
                        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token']; ?>">
                        <button type="submit" class="btn btn-delete">Hapus</button>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

</body>
</html>