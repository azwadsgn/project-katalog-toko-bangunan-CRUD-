<?php
session_start();
require_once '../config/database.php';

$errors = [];
$name = $category = $price = $stock = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $price    = $_POST['price'] ?? '';
    $stock    = $_POST['stock'] ?? '';

    // Requirement Dosen: Validasi input
    if (strlen($name) < 3) {
        $errors[] = "Nama material minimal harus 3 karakter.";
    } else {
        // Validasi Nama Unik via PDO Prepare
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM products WHERE name = ?");
        $stmt->execute([$name]);
        if ($stmt->fetchColumn() > 0) {
            $errors[] = "Nama material sudah ada di database (Nama harus unik).";
        }
    }

    if (empty($category)) {
        $errors[] = "Kategori material wajib dipilih.";
    }

    if (!is_numeric($price) || $price <= 0) {
        $errors[] = "Harga harus berupa angka dan bernilai > 0.";
    }

    if (!is_numeric($stock) || $stock < 0) {
        $errors[] = "Stok harus berupa angka dan bernilai >= 0.";
    }

    // Simpan jika tidak ada error
    if (empty($errors)) {
        // Requirement Dosen: INSERT -> $pdo->prepare(...)
        $stmt = $pdo->prepare("INSERT INTO products (name, category, price, stock) VALUES (?, ?, ?, ?)");
        $stmt->execute([$name, $category, $price, $stock]);

        $_SESSION['flash_message'] = "Material berhasil ditambahkan!";
        
        // PRG Pattern (Post/Redirect/Get) agar tidak terduplikasi saat refresh[cite: 1]
        header("Location: index.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Material Baru</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f4f6f9; }
        .form-card { max-width: 500px; margin: auto; background: white; padding: 20px; border-radius: 8px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input, select { width: 100%; padding: 8px; box-sizing: border-box; }
        .error { color: red; margin-bottom: 15px; }
        .btn { padding: 10px 15px; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-block; }
        .btn-submit { background: #28a745; color: white; }
        .btn-cancel { background: #6c757d; color: white; }
    </style>
</head>
<body>

<div class="form-card">
    <h2>Tambah Material Bangunan</h2>

    <?php if (!empty($errors)): ?>
        <div class="error">
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?= htmlspecialchars($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="create.php">
        <div class="form-group">
            <label>Nama Material:</label>
            <input type="text" name="name" value="<?= htmlspecialchars($name); ?>" required>
        </div>

        <div class="form-group">
            <label>Kategori:</label>
            <select name="category" required>
                <option value="">-- Pilih Kategori --</option>
                <option value="Semen & Pasir" <?= $category === 'Semen & Pasir' ? 'selected' : ''; ?>>Semen & Pasir</option>
                <option value="Cat & Pelapis" <?= $category === 'Cat & Pelapis' ? 'selected' : ''; ?>>Cat & Pelapis</option>
                <option value="Pipa & Sanitasi" <?= $category === 'Pipa & Sanitasi' ? 'selected' : ''; ?>>Pipa & Sanitasi</option>
                <option value="Besi & Baja" <?= $category === 'Besi & Baja' ? 'selected' : ''; ?>>Besi & Baja</option>
                <option value="Kayu & Kayu Olahan" <?= $category === 'Kayu & Kayu Olahan' ? 'selected' : ''; ?>>Kayu & Kayu Olahan</option>
            </select>
        </div>

        <div class="form-group">
            <label>Harga (Rp):</label>
            <input type="number" step="0.01" name="price" value="<?= htmlspecialchars($price); ?>" required>
        </div>

        <div class="form-group">
            <label>Stok:</label>
            <input type="number" name="stock" value="<?= htmlspecialchars($stock); ?>" required>
        </div>

        <button type="submit" class="btn btn-submit">Simpan Material</button>
        <a href="index.php" class="btn btn-cancel">Batal</a>
    </form>
</div>

</body>
</html>