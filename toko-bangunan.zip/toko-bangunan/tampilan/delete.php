<?php
session_start();
require_once '../config/database.php';

$id = $_GET['id'] ?? null;
if (!$id) {
    header("Location: index.php");
    exit;
}

// Requirement Dosen: SELECT by ID -> $pdo->prepare(...)[cite: 1]
$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch();

if (!$product) {
    header("Location: index.php");
    exit;
}

$errors = [];
$name     = $product['name'];
$category = $product['category'];
$price    = $product['price'];
$stock    = $product['stock'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $price    = $_POST['price'] ?? '';
    $stock    = $_POST['stock'] ?? '';

    // Validasi input[cite: 1]
    if (strlen($name) < 3) {
        $errors[] = "Nama material minimal harus 3 karakter.";
    } else {
        // Cek Unik Nama jika nama diubah[cite: 1]
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM products WHERE name = ? AND id != ?");
        $stmt->execute([$name, $id]);
        if ($stmt->fetchColumn() > 0) {
            $errors[] = "Nama material sudah digunakan oleh produk lain.";
        }
    }

    if (!is_numeric($price) || $price <= 0) {
        $errors[] = "Harga harus bernilai > 0.";
    }

    if (!is_numeric($stock) || $stock < 0) {
        $errors[] = "Stok harus bernilai >= 0.";
    }

    if (empty($errors)) {
        // Requirement Dosen: UPDATE -> $pdo->prepare(...)[cite: 1]
        $stmt = $pdo->prepare("UPDATE products SET name = ?, category = ?, price = ?, stock = ? WHERE id = ?");
        $stmt->execute([$name, $category, $price, $stock, $id]);

        $_SESSION['flash_message'] = "Data material berhasil diperbarui!";
        header("Location: index.php"); // PRG Pattern[cite: 1]
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Material</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f4f6f9; }
        .form-card { max-width: 500px; margin: auto; background: white; padding: 20px; border-radius: 8px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input, select { width: 100%; padding: 8px; box-sizing: border-box; }
        .error { color: red; margin-bottom: 15px; }
        .btn { padding: 10px 15px; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-block; }
        .btn-submit { background: #ffc107; color: #333; }
        .btn-cancel { background: #6c757d; color: white; }
    </style>
</head>
<body>

<div class="form-card">
    <h2>Edit Material Bangunan</h2>

    <?php if (!empty($errors)): ?>
        <div class="error">
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?= htmlspecialchars($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label>Nama Material:</label>
            <input type="text" name="name" value="<?= htmlspecialchars($name); ?>" required>
        </div>

        <div class="form-group">
            <label>Kategori:</label>
            <select name="category" required>
                <option value="Semen & Pasir" <?= $category === 'Semen & Pasir' ? 'selected' : ''; ?>>Semen & Pasir</option>
                <option value="Cat & Pelapis" <?= $category === 'Cat & Pelapis' ? 'selected' : ''; ?>>Cat & Pelapis</option>
                <option value="Pipa & Sanitasi" <?= $category === 'Pipa & Sanitasi' ? 'selected' : ''; ?>>Pipa & Sanitasi</option>
                <option value="Besi & Baja" <?= $category === 'Besi & Baja' ? 'selected' : ''; ?>>Besi & Baja</option>
                <option value="Kayu & Kayu Olahan" <?= $category === 'Kayu & Kayu Olahan' ? 'selected' : ''; ?>>Kayu & Kayu Olahan</option>
            </select>
        </div>

        <div class="form-group">
            <label>Harga (Rp):</label>
            <input type="number" step="0.01" name="price" value="<?= htmlspecialchars($price); ?>" required>
        </div>

        <div class="form-group">
            <label>Stok:</label>
            <input type="number" name="stock" value="<?= htmlspecialchars($stock); ?>" required>
        </div>

        <button type="submit" class="btn btn-submit">Update Material</button>
        <a href="index.php" class="btn btn-cancel">Batal</a>
    </form>
</div>

</body>
</html>