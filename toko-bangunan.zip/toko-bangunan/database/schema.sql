CREATE DATABASE IF NOT EXISTS db_tokobangunan;
USE db_tokobangunan;

CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE,
    category VARCHAR(100) NOT NULL,
    price DECIMAL(12,2) NOT NULL,
    stock INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Contoh Data Awal Produk Toko Bangunan
INSERT INTO products (name, category, price, stock) VALUES
('Semen Tiga Roda 50kg', 'Semen & Pasir', 65000.00, 100),
('Cat Tembok Dulux 5Kg', 'Cat & Pelapis', 185000.00, 25),
('Pipa PVC Wavin 5/8 Inch', 'Pipa & Sanitasi', 35000.00, 50);